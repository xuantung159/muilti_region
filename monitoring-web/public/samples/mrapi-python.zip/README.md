# Project MRAPI - Python

Yeu cau: Python 3.10+. Khong can package ngoai.
Huong dan tieng Viet: https://app.multi-region.io.vn/portal -> Huong dan -> Thuc hanh -> Python.

1. Giai nen, mo PowerShell tai thu muc co main.py. Kiem tra: python --version.
2. Thu backend: curl.exe -i https://jsonplaceholder.typicode.com/todos/1 (can HTTP 200).
3. Dang nhap tai khoan that tren Cong doanh nghiep, khong dung che do DEMO PORTAL.
4. API dich: ten API Todo demo, URL https://jsonplaceholder.typicode.com, timeout 5000. Dang ky va sao chep API ID.
5. API key: ten Project Python Todo, tich API Todo demo, Tao key. Sao chep secret mrk_ ngay.
6. Tao file cau hinh: Copy-Item .env.example .env; notepad .env. Dien API ID va key cua ban, luu Ctrl+S.
7. Chay: python main.py
8. Can HTTP 200, region ap-southeast-1 hoac ap-northeast-1, JSON Todo id=1 va title=delectus aut autem.
   Portal -> Tong quan -> 1 gio -> Lam moi de xem telemetry. Co the cap nhat cham.

Lap 5 request: 1..5 | ForEach-Object { python main.py }
Thu thieu key (thay API_ID_CUA_BAN): curl.exe -i https://api.multi-region.io.vn/proxy/API_ID_CUA_BAN/todos/1
Can HTTP 401. Request bi authorizer chan khong tinh trong telemetry proxy.

.env nam cung thu muc voi main.py, khong phai .env.txt. Khong them dau nhay quanh gia tri.
Bien moi truong he thong duoc uu tien hon .env. Khong commit .env hoac dua key vao frontend.
401/403: kiem tra secret, API ID, pham vi va trang thai key. 404: dung /todos/1, khong dung /orders.
502/504: kiem tra backend truc tiep va URL da dang ky. Khong tu dong theo redirect de tranh chuyen key sang host khac.
Kiem tra ket noi vuot 15 giay se bao loi; Java gioi han timeout ket noi va request.