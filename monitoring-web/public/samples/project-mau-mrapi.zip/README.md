# Project Go kiểm tra tích hợp MRAPI

## Bài demo đã chạy: Go → gateway → API Todo

Hướng dẫn trên web: https://app.multi-region.io.vn/portal → **Hướng dẫn** → **Tích hợp thật: project Go đọc công việc Todo**.

Bài này dùng `https://jsonplaceholder.typicode.com`, không cần tunnel hoặc chạy server mẫu. Cần Go 1.22 trở lên; mở PowerShell trong thư mục có `main.go`, `go.mod` và `.env.example`.

1. Chạy `go version`, `Get-ChildItem -Force`, `go test ./...` để kiểm tra công cụ và project.
2. Chạy `curl.exe -i --max-time 15 https://jsonplaceholder.typicode.com/todos/1`. Cần HTTP 200 và Todo `id: 1`. Đây là gọi backend trực tiếp, chưa qua gateway.
3. Mở Cổng doanh nghiệp trên web, thoát chế độ demo nếu có, đăng nhập/đăng ký tài khoản thật. Key `DEMO_ONLY` không dùng được.
4. Mở **API đích**, nhập **Tên API: API Todo demo**, **URL backend: https://jsonplaceholder.typicode.com**, **Timeout: 5000**. Bấm **Đăng ký API**, kiểm tra **Đang bật**, sao chép API ID sau `ID:`. Không thêm `/todos/1` vào URL backend.
5. Mở **API key**, đặt **Tên ứng dụng: Project Go Todo**, tích **API Todo demo**, bấm **Tạo key**. Sao chép ngay toàn bộ secret `mrk_...`; giữ trang mở tới khi điền xong file cấu hình. ID key trong danh sách không phải secret.
6. Tạo file cấu hình lần đầu bằng hai lệnh bên dưới. Nếu đã có `.env`, chỉ mở để sửa, không sao chép ghi đè.

```powershell
Copy-Item .env.example .env
notepad .env
```

Điền đúng ba dòng sau, thay hai giá trị mẫu bằng API ID và key của bạn. Lưu Ctrl+S. File tên `.env`, không phải `.env.txt`, nằm cùng thư mục `main.go`, không thêm dấu nháy quanh giá trị.

```dotenv
MRAPI_GATEWAY_URL=https://api.multi-region.io.vn
MRAPI_API_ID=API_ID_CUA_BAN
MRAPI_API_KEY=DAN_KEY_MRK_CUA_BAN
```

7. Chạy `go run . /todos/1`. Project đọc `.env`, gửi `x-api-key` tới `/proxy/<apiId>/todos/1`. Cần HTTP 200 và JSON dưới đây. Thời gian và region thay đổi theo lần gọi.

```text
HTTP 200 | 1639 ms | region: ap-southeast-1
{
  "userId": 1,
  "id": 1,
  "title": "delectus aut autem",
  "completed": false
}
```

8. Tạo thêm traffic bằng `1..5 | ForEach-Object { go run . /todos/1 }`. Trở lại portal → **Tổng quan** → **1 giờ** → **Làm mới**; xem tổng lượt gọi, region và key Project Go Todo. Dữ liệu có thể cập nhật chậm. Cùng phiên đăng nhập, mở **Failover & Incidents**; cần còn ít nhất một API key hoạt động.

Thử thiếu key bằng lệnh sau, thay API ID của bạn; cần HTTP 401. Request bị authorizer chặn không được tính trong telemetry proxy.

```powershell
curl.exe -i --max-time 15 "https://api.multi-region.io.vn/proxy/API_ID_CUA_BAN/todos/1"
```

Đã kiểm chứng ngày 10/11/2026 bằng API/key có sẵn: backend, Singapore, Tokyo và domain gateway đều HTTP 200; thiếu/sai key đều HTTP 401. Không tạo tài khoản/key mới trong lần kiểm chứng. Đây là bài tích hợp, chưa tạo sự cố để kiểm chứng failover.

Nếu Go không được nhận diện, cài Go và mở lại PowerShell. Nếu 401/403, kiểm tra secret, quyền API và trạng thái key. Nếu 404, dùng `/todos/1`, không dùng `/orders` cho backend Todo. Nếu 502/504, kiểm tra backend trực tiếp và URL đăng ký. Không commit `.env`; file `.gitignore` trong project đã loại file này. Biến môi trường đang đặt trong terminal được ưu tiên hơn `.env`.

## Tích hợp với backend riêng

Chỉ dùng thư viện chuẩn Go, không cài package. Cần Go 1.22 trở lên.

1. Mở https://app.multi-region.io.vn/portal → đăng nhập/đăng ký tài khoản thật.
2. **API đích** → đăng ký URL backend HTTPS công khai có sẵn, sao chép API ID. Đường dẫn kiểm tra phải tồn tại trên backend đó.
3. **API key** → tạo key có quyền với API vừa đăng ký, sao chép ngay vì key chỉ hiện một lần.
4. Sao chép `.env.example` thành `.env`, dán API ID và key vào.
5. Mở terminal trong `project_test` và chạy:

```powershell
go run . /orders
```

Nếu máy chưa cài Go, bộ Go portable dùng để kiểm thử nằm ngoài project, tại `../artifacts/go-toolchain/go/bin/`. Trong PowerShell có thể chạy:

```powershell
../artifacts/go-toolchain/go/bin/go.exe run . /orders
```

Đổi `/orders` thành route của backend, ví dụ `go run . "/todos/1"` hoặc `go run . "/orders?limit=2"`. URL gọi là `<gateway>/proxy/<apiId>/<route>`, header là `x-api-key`. Server Go đọc `.env` trực tiếp; biến môi trường đã đặt được ưu tiên.

Kết quả gồm HTTP status, thời gian, region (nếu có) và response body. Lỗi mạng hoặc HTTP ngoài 2xx làm chương trình thoát với mã 1. Không in key. Timeout 15 giây, không theo redirect, giới hạn hiển thị 64 KiB.

Sau một lần gọi thành công: xem **Tổng quan** trên portal, thu hồi key trong **API key**, chạy lại để kiểm tra 401/403. Cần gateway/proxy/authorizer/telemetry đã triển khai; key `DEMO_ONLY` không dùng được. Client Go không bị giới hạn CORS như phép thử trong trình duyệt.

Có thể sao chép `.env.example` thành `.env` và điền thủ công. `.env` được gitignore; không commit secret hoặc chụp màn hình key. Client tích hợp nằm ở thư mục gốc; server API mẫu nằm trong `server/`.

## Backend mẫu có HTTPS

Server có `GET /orders` trả đơn hàng mẫu và `GET /health` trả trạng thái. Không phục vụ file trên đĩa, không chứa dữ liệu thật. Nhập URL tunnel in ra vào **URL backend** trên portal, không thêm `/orders`. Đường dẫn gọi từ client là `/orders`.

URL tunnel là tạm thời, chỉ hoạt động khi máy, server và tunnel còn chạy. Khởi động lại tunnel sẽ đổi URL; khi đó sửa URL backend trên portal, nếu không gateway trả 502 `UPSTREAM_UNREACHABLE`. Đây là endpoint mẫu công khai để test.

Mở hai terminal ở `project_test`:

```powershell
# Terminal 1: backend
../artifacts/go-toolchain/go/bin/go.exe run ./server
```

```powershell
# Terminal 2: HTTPS tunnel, lấy URL trycloudflare.com được in ra
../artifacts/tools/cloudflared.exe tunnel --url http://127.0.0.1:8080 --no-autoupdate --protocol http2
```

Không chạy thêm khi server nền vẫn đang giữ cổng 8080. Log tiến trình nền ở `../artifacts/logs/test-backend.*.log` và `../artifacts/logs/test-tunnel.*.log`.

Kiểm thử local (không cần AWS, không tạo API key thật):

```powershell
go test ./...
```
